
# Skeleton Schema
This project provides a minimal template to kickstart schema development for [Helix](https://github.com/nebulouscloud/helix).
It contains all the necessary bootstrapping code, proper file structure, and some documentation to help you get started as
quickly as possible.
