
-- You can define attributes in the attributes/ folder. The unique ID of the attribute will be the same as the name of the file.

ATTRIBUTE.name = "Medical Knowledge"
ATTRIBUTE.description = "Your knowledge of medicine."
ATTRIBUTE.noStartBonus = true -- You cannot spend points to upgrade this attribute when creating the character
